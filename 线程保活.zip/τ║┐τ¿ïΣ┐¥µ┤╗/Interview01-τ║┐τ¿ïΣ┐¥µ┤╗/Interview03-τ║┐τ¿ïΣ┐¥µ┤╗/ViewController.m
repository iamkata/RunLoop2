//
//  ViewController.m
//  Interview03-线程保活
//
//  Created by MJ Lee on 2018/6/3.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "ViewController.h"
#import "MJThread.h"

@interface ViewController ()
@property (strong, nonatomic) MJThread *thread;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.thread = [[MJThread alloc] initWithTarget:self selector:@selector(run) object:nil];
    [self.thread start];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self performSelector:@selector(test) onThread:self.thread withObject:nil waitUntilDone:NO];
    //waitUntilDone:YES 等到子线程任务执行完再执行下面NSLog
    //NO 不用等到子线程执行完再执行下面NSLog(下面NSLog在主线程，test在子线程，同时执行)
    NSLog(@"123");
}

// 子线程需要执行的任务
- (void)test
{
    NSLog(@"%s %@", __func__, [NSThread currentThread]);
    // 没打印dealloc，也没打印----end----
    // -[ViewController test] <MJThread: 0x600000a8fec0>{number = 3, name = (null)}
}

// 这个方法的目的：线程保活
- (void)run {
    NSLog(@"%s %@", __func__, [NSThread currentThread]);
    
    // 往RunLoop里面添加Source\Timer\Observer，Port相关的是Source1事件
    //添加了一个Source1，但是这个Source1也没啥事，所以线程在这里就休眠了，不会往下走，----end----一直不会打印
    
    [[NSRunLoop currentRunLoop] addPort:[[NSPort alloc] init] forMode:NSDefaultRunLoopMode];
    
    //如果不添加Source\Timer\Observer，RunLoop没有任何事件处理就会立马退出。
    [[NSRunLoop currentRunLoop] run];
    
    NSLog(@"%s ----end----", __func__);
}

@end
