//
//  main.m
//  RunLoop源码
//
//  Created by 徐金城 on 2019/12/12.
//  Copyright © 2019 xujincheng. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
